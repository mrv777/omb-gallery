# Core instructions

`@drey/core` is the platform-free wallet core shared by `../extension` and the future
mobile app: vault crypto, key derivation, UTXO classification, transaction
planning/analysis/signing, BIP322, marketplace policy, gateway contract verification,
the scan engine, the gateway client, the messaging op registry, and the provider wire
contracts. The workspace root, `../extension`, `../gateway`, and `../mobile` are
separate Git repositories.

## Boundary rules (machine-enforced, spec §4 / ADR 0001 / ADR 0005)

- No React, no WXT, no `chrome`/`browser` globals anywhere in `src/**`.
- No bitcoinjs-lib ecosystem (`bitcoinjs-lib`, `bip32`, `bip39`, `tiny-secp256k1`) —
  only the @scure stack ships.
- **Zero runtime libsodium.** Crypto arrives only through the injected `CryptoProvider`
  port (`src/domain/vault/crypto-provider.ts`); only `argon2id` is asynchronous.
  `libsodium-wrappers-sumo` is a devDependency used solely by the reference test
  provider in `tests/helpers/`. Do not add it to `dependencies` or import it from
  `src/**`.
- ESLint flat-config blocks for overlapping files replace (not merge) rule options —
  every block that sets `no-restricted-imports` must restate the bitcoin ban.

## Commands

```bash
pnpm test
pnpm typecheck
pnpm lint
pnpm fixtures:sync
pnpm vectors:generate
pnpm recovery:build
pnpm recovery:digest
pnpm recovery:verify
git diff --check
```

## Standalone recovery package

`recovery/` is the ADR 0007 §6 provider-independent recovery tool: a Node CLI
that opens a Vault from its public kit with no gateway, relay, extension, or
network access of any kind. It is deliberately **not** in `package.json`
`exports` — it is a program shipped as a built artifact, not part of the
`@drey/core` API — so adding to it is not an API change.

- It never opens a socket. Do not add an HTTP client, an Electrum client, a
  telemetry call, or an update check. The UTXO set arrives as a file and the
  signed transaction leaves as a file; that is what makes the tool usable on an
  air-gapped machine and auditable in one sitting.
- It uses core's **raw B2** PSBT functions, not the B3 asset-safe wrappers,
  because B3 requires signed gateway evidence that by definition does not exist
  here. `vectors/vault-asset-policy-v1.md` reserves the raw path for exactly
  this.
- `pnpm recovery:verify` builds twice and fails unless the bytes are identical.
  A published artifact digest is only meaningful if the build is reproducible,
  so this is a check that runs, not a claim in a README.
- Digests published in a recovery kit are permanent. Append to
  `recovery/RELEASES.md`; never edit or remove a published row.
- `recovery/dist/` is gitignored. The artifact is published as a release asset
  built from a tag, not committed.

## Golden conformance vectors

`vectors/crypto-conformance.json` is asserted by this repo's vitest suite, by the
extension against its shipping libsodium provider, and by the on-device mobile
conformance screen. Regenerate only with `pnpm vectors:generate` — the generator
cross-checks libsodium against `@noble/hashes`, `@noble/ciphers`, `@noble/curves`, and
`node:crypto` and refuses to write on any mismatch. The negative-control sentinel must
stay: a harness that stops computing must fail, not pass. Never hand-edit the fixture.

## Gateway fixtures

`tests/fixtures/gateway/` holds the signed fixture corpus, byte-synced from the sibling
gateway repo with `pnpm fixtures:sync` (`GATEWAY_REPO` overrides the `../gateway`
default). `tests/fixtures/gateway-drift.test.ts` fails on any divergence. The fixture
signing key is public test data and must never be provisioned to a remotely reachable
service.

## Release and consumption

Consumers pin an exact tag: `git+https://github.com/mrv777/drey-wallet-core.git#vX.Y.Z`.
To release: bump `version` in `package.json`, commit, tag `vX.Y.Z`, push commit and tag,
then update each consumer's pin in its own reviewed change (its drift test enforces
pin/tag/version agreement and a clean sibling worktree). Never point a consumer at a
branch, and never retag a published version. Record the exact core tag in every consumer
release.

## Parity

Keep this file byte-for-byte identical to `AGENTS.md`. Verify from this directory:

```bash
cmp -s AGENTS.md CLAUDE.md
```
